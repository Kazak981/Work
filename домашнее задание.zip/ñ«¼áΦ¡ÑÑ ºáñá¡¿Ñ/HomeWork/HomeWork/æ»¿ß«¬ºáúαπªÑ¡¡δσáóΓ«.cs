﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork

{
    class Списокзагруженныхавто
    {
        public static Random r;
    static void Main()
    {
        r = new Random();

        Службатакси ctrl = Службатакси.instance;
            ctrl.startProcess(4);
            ctrl.printReport();
            Console.ReadLine();
        }
}
}
