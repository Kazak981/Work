﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class Сервер : Сервис
    {

        public Сервер() :
            base()
        {
            calculatingType = "Количество свободных авто";
        }
        public override void calculate()
        {
            throw new NotImplementedException();
        }
    }
}
