﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class  Авто : Работаводителя
    {
        private Способоплаты  Способоплаты;

    public Авто(Способоплаты Способоплаты)
    {
        this.Способоплаты = Способоплаты;
    }
        public int returnCapacity()
        {
            return Способоплаты.returnCapacity() / 2;
        }
    }
}
