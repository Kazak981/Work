﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class Способоплаты : Работаводителя
    {
        public Клиент type;
        public string name { get; set; }

        public int returnCapacity()
        {
            return Списокзагруженныхавто.r.Next(0, 100);
        }
    }
}
