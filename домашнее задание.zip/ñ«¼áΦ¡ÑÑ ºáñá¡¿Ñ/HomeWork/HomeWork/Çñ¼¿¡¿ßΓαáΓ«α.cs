﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
     class Администратор : Сервис
    {
        public Администратор()
            : base()
        {
            calculatingType = "Пешеходный поток";
        }
        public override void calculate()
        {
            throw new NotImplementedException();
        }
    }

    class Директор : Сервис
    {
        public Директор()
            : base()
        {
            calculatingType = "Количество клиентоа";
        }
        public override void calculate()
        {
            throw new NotImplementedException();
        }
    }
}
