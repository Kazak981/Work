﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    abstract class Сервис
    {
        public string calculatingType { get; set; }

        public Сервис() { }

        private void initCalcutating()
        {
            Console.WriteLine("Вычисление ближайшего такси: {0}", calculatingType);
        }
        public void templateMethod()
        {
            initCalcutating();
            calculate();
        }

        public abstract void calculate();
    }
}
