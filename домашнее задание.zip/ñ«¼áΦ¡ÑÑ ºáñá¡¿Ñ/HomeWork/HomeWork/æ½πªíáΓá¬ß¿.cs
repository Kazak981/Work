﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
      class Службатакси
    {
        
        private static Службатакси ctrl;

        public static Службатакси instance
        {
            get
            {
                if (ctrl == null) ctrl = new Службатакси();
                return ctrl;
            }
        }

        Списоксвободныхавто Списоксвободныхавто;
        Dictionary<string, int> streamData;
        public void startProcess(int videoCamNum)
        {
            Списоксвободныхавто = new Списоксвободныхавто(videoCamNum);
            streamData = Списоксвободныхавто.returnCamerasData();
        }

        public void printReport()
        {
            foreach (KeyValuePair<string, int> k in streamData)
            {
                Console.WriteLine("Название службы такси: {0}, Время пребытия: {1}", k.Key, k.Value);
            }
        }

    }
}
