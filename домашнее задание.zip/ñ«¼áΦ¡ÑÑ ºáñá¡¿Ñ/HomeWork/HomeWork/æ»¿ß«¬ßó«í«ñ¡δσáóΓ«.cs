﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class Списоксвободныхавто
    {
        private List<Способоплаты> videoCamList;
        internal static Списоксвободныхавто instance;

        public Списоксвободныхавто(int videoCamNum)
        {
            videoCamList = new List<Способоплаты>();
            createCameras(videoCamNum);
        }

        internal object startProcess(int v)
        {
            throw new NotImplementedException();
        }

        internal void printReport()
        {
            throw new NotImplementedException();
        }

        private void createCameras(int num)
        {
            for (int i = 0; i < num; i++)
            {
                videoCamList.Add(new Способоплаты() { name = "Такси №" + (i + 1) });
            }
        }

        public Dictionary<string, int> returnCamerasData()
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            Авто  Авто;
            foreach (Способоплаты camera in videoCamList)
            {
                Авто = new Авто(camera);
                result.Add(camera.name, Авто.returnCapacity());
            }

            return result;
        }
    }
}
