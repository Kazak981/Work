﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adapter
{
    class Program
    {
        static void Main(string[] args)
        {
            Money money = new Money();

            IGame moneyAdapter = new AdapterGame(money);
            Kost kubik = new Kost();
            Gamer g1 = new Gamer("Sergey");
            Console.WriteLine("Выпало очков {0} для игрока {1}", g1.SeansGame (moneyAdapter), g1.ToString());
            Console.WriteLine("Выпало очков {0} для игрока {1}", g1.SeansGame(kubik), g1.ToString());
        }
    }
}
