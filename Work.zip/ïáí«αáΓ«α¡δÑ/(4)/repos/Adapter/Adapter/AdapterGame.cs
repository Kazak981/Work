﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adapter
{
    class AdapterGame : IGame
    {
        Money mot;

        public AdapterGame (Money mt)
        {
            mot = mt;
        }

        public int Brosok()
        {
            return mot.Brosok();
        }
    }
}
