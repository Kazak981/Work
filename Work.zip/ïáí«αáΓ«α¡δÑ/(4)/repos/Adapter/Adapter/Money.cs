﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adapter
{
    class Money
    {
        Random r;

        public Money()
        {
            r = new Random();
        }

        public int Brosok()
        {
            int res = r.Next(2) + 1;
            return res;
        }
    }
}
