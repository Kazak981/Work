﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Adapter
{
    class Kost : IGame
    {
        Random r;
        public Kost()
        {
            r = new Random();
        }
        public int Brosok()
        {
            int res = r.Next(6) + 1;
            return res;
        }
    }
}
