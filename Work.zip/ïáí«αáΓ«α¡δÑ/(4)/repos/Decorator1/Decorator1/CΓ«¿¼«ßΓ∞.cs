﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator1
{
    class Cтоимость : Options
    {
        public Cтоимость(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Современный";
            this.description = AutoBase.description + ". " +
                this.title + ". Вместительный";
        }

        public override double getCost()
        {
            return AutoBase.getCost() + 1.99;
        }
    }
}