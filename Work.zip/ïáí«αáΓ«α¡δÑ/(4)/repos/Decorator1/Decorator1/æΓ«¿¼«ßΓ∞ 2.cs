﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator1
{
    class Стоимость_2 : Options
    {
        public Стоимость_2(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Стоимость";
            this.description = AutoBase.description + ". " +
                this.title + ". Премиум автомобиль";
        }

        public override double getCost()
        {
            return AutoBase.getCost() + 20.99;
        }
    }
}