﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator1
{
    class Груз : Options
    {
        public Груз(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Наличие личного водителя";
            this.description = AutoBase.description + ". " +
                this.title + ". Наличие кожаного салона";
        }
        public override double getCost()
        {
            return AutoBase.getCost() + 2.99;
        }
    }
}