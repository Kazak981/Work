﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator1
{
    class Program
    {
        
        static void Main()
        {
            Simple Simple = new Simple("Рено", "Renault Megan", 499);
            Console.WriteLine(Simple.getInfo());

            AutoBase mySimple = new Cтоимость(Simple, "Навигация");
            Console.WriteLine(mySimple.getInfo());

            AutoBase mySimple1 = new Комфорт(mySimple, "Надежный");
            Console.WriteLine(mySimple1.getInfo());

            Elite Elite = new Elite("Elite", "Audi RS7", 666);
            Console.WriteLine(Elite.getInfo());

            AutoBase myElite = new Комфорт(Elite, "Защищенный");
            Console.WriteLine(myElite.getInfo());

            AutoBase myElite1 = new Options(myElite, "Салон из кожи");
            Console.WriteLine(myElite1.getInfo());

            AutoBase myElite2 = new Груз(myElite, "Наличие системы адаптивного полного привода");
            Console.WriteLine(myElite2.getInfo());

            Console.ReadLine();
        }
    }
}