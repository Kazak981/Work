﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator1
{
    class Комфорт : Options
    {
        public Комфорт(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Доступный";
            this.description = AutoBase.description + ". " +
                this.title + ". Удобный, качевственное авто";
        }

        public override double getCost()
        {
            return AutoBase.getCost() + 1.9;
        }
    }
}