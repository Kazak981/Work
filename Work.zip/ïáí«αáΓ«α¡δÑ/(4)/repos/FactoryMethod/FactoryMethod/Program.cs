﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FactoryMethod
{
    class Program
    {
        static void Main()
        {
            TransportCompany taxiCompany = new TaxiTransCom("Черная молния");
            TransportService companyService = taxiCompany.Create("Такси", 2);

            double distance = 16.5;
            printInfo(companyService, distance);

            TransportCompany shippingCompany = new ShipTransCom("Движение Вверх");
            companyService = shippingCompany.Create("Карусель", 3);

            distance = 140.7;
            printInfo(companyService, distance);

            TransportCompany drunkDriverCompany = new DrunkTransCom("Спартанец");
            companyService = drunkDriverCompany.Create("Трезвый водитель", 25);

            distance = 150.7;
            printInfo(companyService, distance);

            Console.ReadLine();
        }

        private static void printInfo(TransportService transpService, double distance)
        {
            Console.WriteLine("{0}, расстояние: {1}, стоимость: {2}"
                , transpService.ToString(), distance, transpService.CostTransportation(distance));
        }
    }
}