﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FactoryMethod
{
    abstract class TransportCompany
    {
        public string Name { get; set; }

        public TransportCompany(string name)
        {
            Name = name;
        }

        abstract public TransportService Create(string Name, int cost);
    }
}