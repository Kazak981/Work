﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Command
{
    class ConcreteCommand { }
    class add : Command
    {
        public add(ArithmeticUnit unit, double operand)
        {
            this.unit = unit;
            this.operand = operand;
        }
        public override void execute()
        {
            unit.run('+', operand);
        }

        public override void unExecute()
        {
            unit.run('-', operand);
        }
    }

    class sub : Command
    {
        public sub(ArithmeticUnit unit, double operand)
        {
            this.unit = unit;
            this.operand = operand;
        }
        public override void execute()
        {
            unit.run('-', operand);
        }

        public override void unExecute()
        {
            unit.run('+', operand);
        }
    }

    class mul : Command
    {
        public mul(ArithmeticUnit unit, double operand)
        {
            this.unit = unit;
            this.operand = operand;
        }
        public override void execute()
        {
            unit.run('*', operand);
        }

        public override void unExecute()
        {
            unit.run('/', operand);
        }
    }

    class div : Command
    {
        public div(ArithmeticUnit unit, double operand)
        {
            this.unit = unit;
            this.operand = operand;
        }
        public override void execute()
        {
            unit.run('/', operand);
        }

        public override void unExecute()
        {
            unit.run('*', operand);
        }
    }
}
