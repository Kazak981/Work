﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DZ
{
    abstract class Navigation
    {
        public string title { get; set; }

        public abstract void navigate();
    }
}
