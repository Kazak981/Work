﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ
{
    class Taxi : Navigation
    {
        public Taxi()
    {
        title = "Прокладка маршрута для ближайшего такси";
    }
    public override void navigate()
    {
        Console.WriteLine("Позволяет построить маршрут до клиента.");
    }
}
}