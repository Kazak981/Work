﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DZ
{
    class Маршрут : Navigation
    {
        public Маршрут()
    {
        title = "Прокладка маршрута до адреса";
    }
    public override void navigate()
    {
        Console.WriteLine("Позволяет построить маршрут до адреса.");
    }
}
}