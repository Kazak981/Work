﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DZ
{
    class Client : Navigation
    {
        public Client()
        {
            title = "Местонахождения клиента";
        }
        public override void navigate()
        {
            Console.WriteLine("Позволяет найти местоположение клиента.");
        }
    }
}