﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DZ
{
     class Map
    {
        private Navigation Navigation;

        public Map(Navigation Navigation)
        {
            this.Navigation = Navigation;
        }

        public void navigate()
        {
            Navigation.navigate();
        }
    }
}