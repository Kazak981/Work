﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Climat
{
    class Sensor : ISensor
    {
        int min = -150;
        int max = 220;
        Random r;

        public Sensor()
        {
            r = new Random();
        }
        public double getTemperature()
        {
            return (double)r.Next(min * 10, max * 10) / 10;
        }
    }
}
