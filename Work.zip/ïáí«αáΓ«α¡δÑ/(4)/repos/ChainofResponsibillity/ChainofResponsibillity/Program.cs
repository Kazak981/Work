﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChainofResponsibillity
{
    class Program
    {
        static void Main()
        {
            Reciever Reciever = new Reciever(false, false, true);

            PaymentHandler bankPaymentHandler = new bankPaymentHandler();
            PaymentHandler moneyPaymentHandler = new moneyPaymentHandler();
            PaymentHandler payPalPaymentHandler = new payPalPaymentHandler();

            bankPaymentHandler.successor = payPalPaymentHandler;
            payPalPaymentHandler.successor = payPalPaymentHandler;



            payPalPaymentHandler.Handle(Reciever);

            Console.ReadLine();
        }
    }
}
