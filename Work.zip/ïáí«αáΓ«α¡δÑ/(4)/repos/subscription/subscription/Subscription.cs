﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subscription
{
    abstract class Subscription
    {
        public int cost { get; set; }
        public string name { get; set; }

        public Subscription(string name, int cost)
        {
            this.cost = cost;
            this.name = name;
        }

        public Subscription() { }

        private void SubscriptionInfo()
        {
            Console.WriteLine("Абонимент: \"{0}\" Цена: {1}", name, cost);
        }

        public void SubscriptionMethod()
        {
            SubscriptionInfo();
            SubscriptionDescription();
        }

        public abstract void SubscriptionDescription();


    }
}
