﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subscription
{
    class Monthsubscription : Subscription
    {
        public Monthsubscription()
        {
            name = "Месячный";
            cost = 3000;
        }

        public override void SubscriptionDescription()
        {
            Console.WriteLine("Билет позволяет в течение месяца посещать спортивный зал\r\n");
        }
    }
}
