﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subscription
{
    class Program
    {

        static void Main()
        {
        Subscription Subscription = new Monthsubscription();
        Subscription.SubscriptionMethod();
         

        Subscription = new Yearsubscription();
        Subscription.SubscriptionMethod();

        Console.ReadLine();
        }
     }
}
