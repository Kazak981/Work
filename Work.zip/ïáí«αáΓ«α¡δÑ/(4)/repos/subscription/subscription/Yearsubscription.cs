﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subscription
{
    class Yearsubscription : Subscription
    {
        public Yearsubscription()
        {
            name = "Месячный";
            cost = 25000;
        }

        public override void SubscriptionDescription()
        {
            Console.WriteLine("Билет позволяет в течение месяца посещать спортивный зал\r\n");
        }
    }
}
