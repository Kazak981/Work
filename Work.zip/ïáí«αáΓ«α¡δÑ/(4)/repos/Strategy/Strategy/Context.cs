﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Strategy
{
    class Context
    {
        StrategySort StrategySort;
        int[] array;

        public Context(StrategySort StrategySort, int[] array)
        {
            this.StrategySort = StrategySort;
            this.array = array;
        }

        public void sort()
        {
            StrategySort.sort(array);
        }

        public void printArray()
        {
            Console.WriteLine(StrategySort.title);
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
