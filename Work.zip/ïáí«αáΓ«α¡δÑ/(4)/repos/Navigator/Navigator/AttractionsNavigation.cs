﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Navigator
{
    class AttractionsNavigation : StrategyNavigation
    {
        public AttractionsNavigation()
        {
            title = "Прокладка маршрута по достопримечательностям";
        }
        public override void navigate()
        {
            Console.WriteLine("Позволяет построить маршрут по достопримечательностям.");

        }
    }
}
