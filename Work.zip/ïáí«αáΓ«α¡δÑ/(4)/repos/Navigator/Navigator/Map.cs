﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Navigator
{
    class Map
    {
        private StrategyNavigation StrategyNavigation;

        public Map(StrategyNavigation StrategyNavigation)
        {
            this.StrategyNavigation = StrategyNavigation;
        }

        public void navigate()
        {
            StrategyNavigation.navigate();
        }
    }
}