﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Navigator
{
    class BicyckeNavigation : StrategyNavigation
    {
        public BicyckeNavigation()
        {
            title = "Прокладка велосипедного маршрута";
        }
        public override void navigate()
        {
            Console.WriteLine("Позволяет построить велосипедный маршрут.");
        }
    }
}