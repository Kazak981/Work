﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Navigator
{
    class RoadNavigation : StrategyNavigation
    {
        public RoadNavigation()
        {
            title = "Прокладка автомобильного маршрута";
        }
        public override void navigate()
        {
            Console.WriteLine("Позволяет построить маршрут по автодороге.");
        }
    }
}