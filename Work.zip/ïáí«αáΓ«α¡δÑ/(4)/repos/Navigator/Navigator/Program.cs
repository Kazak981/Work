﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Navigator
{
    class Program
    {
        static void Main()
        {
            StrategyNavigation myNavigation = new PublicTransportNavigation();
            Map map = new Map(myNavigation);
            Console.WriteLine(myNavigation.title);
            map.navigate();

            myNavigation = new RoadNavigation();
            map = new Map(myNavigation);
            Console.WriteLine(myNavigation.title);
            map.navigate();

            myNavigation = new WalkNavigation();
            map = new Map(myNavigation);
            Console.WriteLine(myNavigation.title);
            map.navigate();

            myNavigation = new BicyckeNavigation();
            map = new Map(myNavigation);
            Console.WriteLine(myNavigation.title);
            map.navigate();

            myNavigation = new AttractionsNavigation();
            map = new Map(myNavigation);
            Console.WriteLine(myNavigation.title);
            map.navigate();

            Console.ReadLine();
        }
    }
}