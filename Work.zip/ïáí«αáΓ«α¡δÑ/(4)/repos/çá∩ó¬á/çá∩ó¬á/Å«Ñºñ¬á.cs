﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Заявка
{
    class Поездка : Заявка
    {
        public Поездка()
        {
            name = "Проезд по маршруку";
            cost = 100;
        }

        public override void ЗаявкаDescription()
        {
            Console.WriteLine("Фиксированная плата за проезд\r\n");
        }
    }
}
