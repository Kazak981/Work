﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Заявка
{
    abstract class Заявка
    {
        public int cost { get; set; }
        public string name { get; set; }

        public Заявка(string name, int cost)
        {
            this.cost = cost;
            this.name = name;
        }

        public Заявка() { }

        private void ЗаявкаInfo()
        {
            Console.WriteLine("Абонимент: \"{0}\" Цена: {1}", name, cost);
        }

        public void ЗаявкаMethod()
        {
            ЗаявкаInfo();
            ЗаявкаDescription();
        }

        public abstract void ЗаявкаDescription();


    }
}
