﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Заявка
{
    class Поездка1 : Заявка
    {
        public Поездка1()
        {
            name = "Проезд по маршруту с остановками";
            cost = 150;
        }

        public override void ЗаявкаDescription()
        {
            Console.WriteLine("Позволяет вызвать такси и сделать до 2 остановок на маршруте\r\n");
        }
    }
}