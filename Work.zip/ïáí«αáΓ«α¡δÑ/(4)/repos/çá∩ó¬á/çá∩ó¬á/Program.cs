﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Заявка
{
    class Program
    {

        static void Main()
        {
            Заявка Заявка = new Поездка();
            Заявка.ЗаявкаMethod();


            Заявка = new Поездка1();
            Заявка.ЗаявкаMethod();

            Console.ReadLine();
        }
    }
}
