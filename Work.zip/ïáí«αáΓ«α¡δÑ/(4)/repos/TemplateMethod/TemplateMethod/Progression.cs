﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TemplateMethod
{
    abstract class Progression
    {
        public int first { get; set; }
        public int last { get; set; }
        public int step { get; set; }

        public string ProgressionType { get; set; }

        public List<int> ProgressionList;

        public Progression(int first, int last, int step)
        {
            this.first = first;
            this.last = last;
            this.step = step;

            ProgressionList = new List<int>();
        }

        public void templateMethod()
        {
            initializeProgression(first, last, step);
            progress();
            print(ProgressionList);
        }

        private void print(List<int> Progression)
        {
            Console.Write("[");
            foreach (int item in Progression) Console.Write(" " + item);
            Console.WriteLine(" ]");
        }

        public abstract void progress();

        private void initializeProgression(int first, int last, int step)
        {
            Console.WriteLine("{3} прогрессия от {0} до {1} с шагом {2}:", first, last, step, ProgressionType);
        }
    }
}
