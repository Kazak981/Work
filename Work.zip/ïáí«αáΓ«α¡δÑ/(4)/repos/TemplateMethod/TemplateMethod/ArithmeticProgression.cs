﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TemplateMethod
{
    class ArithmeticProgression : Progression
    {
        public ArithmeticProgression(int first, int last, int step)
           : base(first, last, step)
    {
        ProgressionType = "Арифметическая";
    }

    public override void progress()
    {
        int counter = first;
        while (counter <= last)
        {
            ProgressionList.Add(counter);
            counter += step;
        }
    }
}
}