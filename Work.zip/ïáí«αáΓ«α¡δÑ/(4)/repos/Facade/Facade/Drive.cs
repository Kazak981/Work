﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facade
{
    class Drive
    {
        public event EventHandler DriveEvent;

        private string twistString;

        public string twist
        {
            get { return twistString; }
            set
            {
                twistString = value;
                if (DriveEvent != null) DriveEvent(this, new EventArgs());
            }
        }

        public Drive()
        {
            twist = "Исходная позиция";
        }

        public void turnLeft()
        {
            twist = "Поворот налево";
        }

        public void turnRight()
        {
            twist = "Поворот направо";
        }

        public void stop()
        {
            twist = "Стоп";
        }

        public string getState()
        {
            return String.Format("Состояние привода: {0}", twist);
        }
    }
}
