﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facade
{
    class Power
    {
        public event EventHandler PowerEvent;

        private int PowerValue;

        public int MicrowavePower
        {
            get { return PowerValue; }
            set
            {
                PowerValue = value;

                if (PowerEvent != null) PowerEvent(this, new EventArgs());
            }
        }

        public string getState()
        {
            return String.Format("Задана мощность {0} Вт", MicrowavePower);
        }
    }
}