﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facade
{
    class Program
    {
        static void Main()
        {
            Drive Drive = new Drive();
            Power Power = new Power();
            Notification Notification = new Notification();

            Microwave Electricgrill = new Microwave(Drive, Power, Notification);

            Power.PowerEvent += Power_PowerEvent;
            Drive.DriveEvent += Drive_DriveEvent;
            Notification.NotificationEvent += Notification_NotificationEvent;

            Console.WriteLine("Разморозка");
            Electricgrill.defrost();

            Console.WriteLine();

            Console.WriteLine("Приготовление");
            Electricgrill.cooking();

            Console.ReadLine();
        }

        static void Notification_NotificationEvent(object sender, EventArgs e)
        {
            Console.WriteLine((sender as Notification).getState());
        }

        static void Drive_DriveEvent(object sender, EventArgs e)
        {
            Console.WriteLine((sender as Drive).getState());
        }

        static void Power_PowerEvent(object sender, EventArgs e)
        {
            Console.WriteLine((sender as Power).getState());
        }
    }
}
