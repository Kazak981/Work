﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facade
{
    class Microwave
    {
        private Drive Drive;
        private Power Power;
        private Notification Notification;

        public Microwave(Drive Drive, Power Power, Notification Notification)
        {
            this.Drive = Drive;
            this.Power = Power;
            this.Notification = Notification;
        }

        public void defrost()
        {
            Notification.startNotification();
            Power.MicrowavePower = 1000;
            Drive.turnRight();
            Drive.turnRight();
            Power.MicrowavePower = 500;
            Drive.stop();
            Drive.turnLeft();
            Drive.turnLeft();
            Power.MicrowavePower = 200;
            Drive.stop();
            Drive.turnRight();
            Drive.turnRight();
            Drive.stop();
            Power.MicrowavePower = 0;
            Notification.stopNotification();
        }

        public void cooking()
        {
            Notification.startNotification();
            Power.MicrowavePower = 1000;
            Drive.turnRight();
            Power.MicrowavePower = 500;
            Drive.stop();
            Drive.turnLeft();
            Power.MicrowavePower = 200;
            Drive.stop();
            Drive.turnRight();
            Power.MicrowavePower = 1000;
            Drive.turnRight();
            Drive.stop();
            Power.MicrowavePower = 0;
            Notification.stopNotification();
        }
    }
}