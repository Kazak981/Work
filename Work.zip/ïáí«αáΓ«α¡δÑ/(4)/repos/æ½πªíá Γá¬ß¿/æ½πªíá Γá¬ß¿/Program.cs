﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Перевод
{
    class Program
    {
        static void Main()
        {
            Reciever Reciever = new Reciever(false, true,false );

            PaymentHandler bankPaymentHandler = new bankPaymentHandler();
            PaymentHandler moneyPaymentHandler = new moneyPaymentHandler();
            PaymentHandler payPalPaymentHandler = new payPalPaymentHandler();

            bankPaymentHandler.successor = moneyPaymentHandler;
            payPalPaymentHandler.successor = moneyPaymentHandler;



            payPalPaymentHandler.Handle(Reciever);

            Console.ReadLine();
        }
    }
}

