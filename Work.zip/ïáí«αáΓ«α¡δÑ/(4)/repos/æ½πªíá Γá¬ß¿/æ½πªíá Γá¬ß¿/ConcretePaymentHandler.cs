﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Перевод
{
     class bankPaymentHandler : PaymentHandler
    {

        public override void Handle(Reciever Reciever)
        {
            if (Reciever.bankTransfer == true) Console.WriteLine("Выполняется банковский перевод");
            else if (successor != null) successor.Handle(Reciever);
        }
    }

    class moneyPaymentHandler : PaymentHandler
    {
        public override void Handle(Reciever Reciever)
        {
            if (Reciever.moneyTransfer == true) Console.WriteLine("Выполняется денежный перевод");
            else if (successor != null) successor.Handle(Reciever);
        }
    }

    class payPalPaymentHandler : PaymentHandler
    {
        public override void Handle(Reciever Reciever)
        {
            if (Reciever.payPalTransfer == true) Console.WriteLine("Выполняется перевод по системе PayPal");
            else if (successor != null) successor.Handle(Reciever);
        }
    }
}
