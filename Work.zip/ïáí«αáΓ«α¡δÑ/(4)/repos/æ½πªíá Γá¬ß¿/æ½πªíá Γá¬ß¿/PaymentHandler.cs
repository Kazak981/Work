﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Перевод
{
    abstract class PaymentHandler
    {
        public PaymentHandler successor { get; set; }
        public abstract void Handle(Reciever Reciever);
    }
}