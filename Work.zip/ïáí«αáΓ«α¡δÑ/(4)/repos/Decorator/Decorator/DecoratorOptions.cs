﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator
{
    class DecoratorOptions : AutoBase
    {
        public AutoBase AutoBase { protected get; set; }

        public string title { get; set; }

        public DecoratorOptions(AutoBase AutoBase, string title)
        {
            this.AutoBase = AutoBase;
            this.title = title;
        }

        public override double getCost()
        {
            throw new NotImplementedException();
        }
    }
}
