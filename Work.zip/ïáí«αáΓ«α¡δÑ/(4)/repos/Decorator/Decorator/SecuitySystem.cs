﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator
{
    class SecuritySystem : DecoratorOptions
    {
        public SecuritySystem(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Повышенной безопасности";
            this.description = AutoBase.description + ". " +
                this.title + ". Передние боковые подушки безопасности, ESP -система динамической стабилизации автомобиля";
        }

        public override double getCost()
        {
            return AutoBase.getCost() + 20.99;
        }
    }
}