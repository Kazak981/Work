﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator
{
    class Program
    {
        static void Main()
    {
        Renault Renault = new Renault("Рено", "Renault Megan", 499);
        Console.WriteLine(Renault.getInfo());

        AutoBase myRenault = new MediaNAV(Renault, "Навигация");
        Console.WriteLine(myRenault.getInfo());

        AutoBase myRenault1 = new SecuritySystem(myRenault, "Безопасность");
        Console.WriteLine(myRenault1.getInfo());

        Audi Audi = new Audi ("Audi", "Audi RS7", 666);
        Console.WriteLine(Audi.getInfo());

        AutoBase myAudi = new SecuritySystem(Audi, "Защищенный");
        Console.WriteLine(myAudi.getInfo());

        AutoBase myAudi1 = new Options(myAudi, "Салон из кожи");
        Console.WriteLine(myAudi1.getInfo());

        AutoBase myAudi2 = new QuattroSystem(myAudi, "Наличие системы адаптивного полного привода");
        Console.WriteLine(myAudi2.getInfo());

        Console.ReadLine();
    }
}
}