﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator
{
    class QuattroSystem : DecoratorOptions
    {
        public QuattroSystem(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Система адаптивного полного привода";
            this.description = AutoBase.description + ". " +
                this.title + ". Нажми на кнопку - получишь результат";
        }
        public override double getCost()
        {
            return AutoBase.getCost() + 250.69;
        }
    }
}