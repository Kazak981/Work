﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator
{
    class MediaNAV : DecoratorOptions
    {
        public MediaNAV(AutoBase AutoBase, string title)
            : base(AutoBase, title)
        {
            this.name = AutoBase.name + ". Современный";
            this.description = AutoBase.description + ". " +
                this.title + ". Обновленная мультимедийная навигационная система";
        }

        public override double getCost()
        {
            return AutoBase.getCost() + 15.99;
        }
    }
}