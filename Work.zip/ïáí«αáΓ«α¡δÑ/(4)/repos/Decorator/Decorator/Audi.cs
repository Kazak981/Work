﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decorator
{
    class Audi : AutoBase
    {
        public Audi(string name, string description, double costBase)
        {
            this.name = name;
            this.description = description;
            this.costBase = costBase;
        }

        public override double getCost()
        {
            return costBase * 2.23;
        }
    }
}
